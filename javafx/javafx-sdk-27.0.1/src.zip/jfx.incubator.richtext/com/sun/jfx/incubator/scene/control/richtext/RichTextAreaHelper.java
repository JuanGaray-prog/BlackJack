/*
 * Copyright (c) 2025, 2026, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.sun.jfx.incubator.scene.control.richtext;

import com.sun.javafx.util.Utils;
import jfx.incubator.scene.control.richtext.RichTextArea;
import jfx.incubator.scene.control.richtext.TextPos;

/**
 * Manages RichTextArea Accessor.
 */
public class RichTextAreaHelper {

    public interface Accessor {
        public boolean getText(RichTextArea t, TextPos start, TextPos end, StringBuilder sb, int limit);
        public void setDocumentArea(RichTextArea t, double minX, double minY, double width, double height);
    }

    static {
        Utils.forceInit(RichTextArea.class);
    }

    private static Accessor accessor;

    public static void setAccessor(Accessor a) {
        if (accessor != null) {
            // this code might break when RTA is created outside of the fx application thread
            // I am not sure what this check does really
            throw new IllegalStateException();
        }
        accessor = a;
    }

    public static boolean getText(RichTextArea t, TextPos start, TextPos end, StringBuilder sb, int limit) {
        return accessor.getText(t, start, end, sb, limit);
    }

    public static void setDocumentArea(RichTextArea t, double minX, double minY, double width, double height) {
        accessor.setDocumentArea(t, minX, minY, width, height);
    }
}
